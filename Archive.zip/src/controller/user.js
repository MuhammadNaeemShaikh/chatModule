const User = require('../models/user');
const jwt = require('jsonwebtoken');
const Otp = require('../models/otp');
const bcrypt = require('bcryptjs')
const crypto = require('crypto');
const createToken = (id) => {
  return jwt.sign({id}, process.env.JWT_KEY, { expiresIn: '3d' });
};

const loginUser = async (req, res) => {
  const {email, password} = req.body;

  try {
    const user = await User.login(email, password);

    // create a token
    const token = createToken(user._id);
    const type = user.type;
    const id = user._id;
    const fhirid = user.fhirid;

    res.status(200).json({email, token, type, id, fhirid});

  } catch (error) {
    res.status(400).json({msg: error.message});
  }
};

// signup a user
const signupUser = async (req, res) => {
  const {email, password, type} = req.body;

  try {
    const user = await User.signup(email, password, type);
    // create a token
    const token = createToken(user._id);
    const id = user._id;

    res.status(200).json({email, token, id, type});
  } catch (error) {
    res.status(400).json({msg: error.message});
  }
};

//node mailer code
var nodemailer = require('nodemailer');

const mailer = ( email , otp) =>{
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 465,
    secure: false,
    auth: {
        user: 'aqib.kk999@gmail.com',
        pass: 'llmoknxbxzlzvqcx',
    },
});
var mailOptions = {
    from: 'aqib.kk999@gmail.com',
    to: email,
    subject: 'Sending Email using Node.js',
    text: `Your Otp is ${otp}`
};
transporter.sendMail(mailOptions, function(error, info){
    if (error) {
        console.log(error);
    } else {
        console.log('Email sent: from nodemailer' + info.response);
    }
});
}

// Send Email
const verifyEmail = async (req,res) =>{
   let data = await User.findOne({email:req.body.email});

  if(data){
    const otpCode = '0123456789';
     let result;
      async function generateRandomString(length) {
         result = '';
         let charactersLength = otpCode.length;
         for (let i = 0; i < length; i++) {
           result += otpCode.charAt(crypto.randomBytes(1)[0] % charactersLength);
         }
      }
    console.log(generateRandomString(4));
      // let otpCode = Math.floor((Math.random()*10000) + 1);
      let otpData = new Otp({
        email: req.body.email,
        code: result,
        expiresIn : new Date().getTime() + 0.002*1000
      })
     let otpResponse = await otpData.save();
     res.status(200).json({msg:'Please Check Your Email'});
     mailer(req.body.email,otpResponse.code);

  }
  else{
    res.status(404).json({msg:'Your email id doesnot exist'});
  }
}

// Verify OTP
const verifyOtp = async( req,res) =>{
  let data = await Otp.findOne({email:req.body.email,code:req.body.code});
  if(data)
  {
    res.status(200).json({msg:'Email Verified'})
  }
  else{
    res.status(404).json({msg:'Invalid OTP '})
  }
} 


//forgot password 
const forgotPassword = async (req,res) => {
  let data = await Otp.findOne({email:req.body.email,code:req.body.code});
  if(data){
 

    // else {
      try {
        
        const password = req.body.password;
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password, salt);
        const user = await User.findOneAndUpdate({email:req.body.email}, {
            password: hash
        },{
          new: true
        });
        await user.save()
        res.status(200).json({msg: 'Password Change Sucessfully'});
        
       } catch (error) {
          res.status(500).json({error: error.message });
       }
    
   
  }
  else{
    res.status(404).json({msg:'Invalid OTP '})
  }


}


module.exports = { signupUser, loginUser, verifyEmail , forgotPassword, verifyOtp};

