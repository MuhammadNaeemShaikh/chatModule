const LegalSign = require("../models/LegalSign");


const LegalSignClt = {
    createLegalSign: (async (req, res) => {
        try {
            const { name, physician, neuroCare, address, email, sign } = req.body;
            const legalSign = await LegalSign.create({
                name, physician, neuroCare, address, email, sign
            });
            res.status(201).json({
                success: true,
                legalSign: legalSign
            })
        } catch (err) {
            res.status(201).json({
                success: false,
                Error: err.message
            })
        }
    })
    ,
    getLegalSign: (async (req, res) => {
        try {
            const legalSign = await LegalSign.find();
            res.status(201).json({
                success: true,
                legalSign: legalSign
            })
        } catch (err) {
            res.status(201).json({
                success: false,
                Error: err.message
            })
        }
    })
}
module.exports = LegalSignClt;