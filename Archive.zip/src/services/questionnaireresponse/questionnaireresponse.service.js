/*eslint no-unused-vars: "warn"*/

const { VERSIONS } = require('@asymmetrik/node-fhir-server-core').constants;
const { resolveSchema } = require('@asymmetrik/node-fhir-server-core');
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const { ObjectID } = require('mongodb');
const logger = require('@asymmetrik/node-fhir-server-core').loggers.get();

const globals = require('../../globals');
const { getUuid } = require('../../utils/uid.util');
const moment = require('moment-timezone');
const { COLLECTION, CLIENT_DB } = require('../../constants');


let getQuestionnaireResponse = (base_version) => {
  return resolveSchema(base_version, 'QuestionnaireResponse');
};

let getMeta = (base_version) => {
  return resolveSchema(base_version, 'Meta');
};

module.exports.search = (args) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let author = args['author'];
    let authored = args['authored'];
    let based_on = args['based-on'];
    let _context = args['_context'];
    let identifier = args['identifier'];
    let parent = args['parent'];
    let patient = args['patient'];
    let questionnaire = args['questionnaire'];
    let source = args['source'];
    let status = args['status'];
    let subject = args['subject'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let QuestionnaireResponse = getQuestionnaireResponse(base_version);

    // Cast all results to QuestionnaireResponse Class
    let questionnaireresponse_resource = new QuestionnaireResponse();
    // TODO: Set data with constructor or setter methods
    questionnaireresponse_resource.id = 'test id';

    // Return Array
    resolve([questionnaireresponse_resource]);
  });

module.exports.searchById = (args) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> searchById');

    let { base_version, id } = args;

    let QuestionnaireResponse = getQuestionnaireResponse(base_version);

    // TODO: Build query from Parameters
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.QUESTIONNAIRE_RESPONCE}_${base_version}`);
    // TODO: Query database
    collection.findOne({ id: id.toString() }, (err, questionnaireResponse) => {
      if (err) {
        logger.error('Error with Patient.searchById: ', err);
        return reject(err);
      }
      if (questionnaireResponse) {
        resolve(new QuestionnaireResponse(questionnaireResponse));
      }
      resolve();
    });
  });

module.exports.create = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> create');

    let { base_version } = args;

    // Make sure to use this ID when inserting this resource
    let id = new ObjectID().toString();

    let QuestionnaireResponse = getQuestionnaireResponse(base_version);
    let Meta = getMeta(base_version);
    let resource = req.body;
    // TODO: determine if client/server sets ID

    // Cast resource to QuestionnaireResponse Class
    let questionnaireresponse_resource = new QuestionnaireResponse(resource);
    questionnaireresponse_resource.meta = new Meta();
    // TODO: set meta info
// Grab an instance of our DB and collection
let db = globals.get(CLIENT_DB);
let collection = db.collection(`${COLLECTION.QUESTIONNAIRERESPONSE}_${base_version}`);
    // TODO: save record to database
    let doc = JSON.parse(JSON.stringify(questionnaireresponse_resource.toJSON()));
    Object.assign(doc, { id: id });
    let history_doc = Object.assign({}, doc);
  Object.assign(doc, { id: id });

  // Insert our patient record
  collection.insertOne(doc, (err) => {
    if (err) {
      logger.error('Error with QUESTIONNAIRERESPONSE.create: ', err);
      return reject(err);
    }

    // Save the resource to history
    let history_collection = db.collection(`${COLLECTION.QUESTIONNAIRERESPONSE}_${base_version}_History`);

    // Insert our patient record to history but don't assign _id
    return history_collection.insertOne(history_doc, (err2) => {
      if (err2) {
        logger.error('Error with QUESTIONNAIREHistory.create: ', err2);
        return reject(err2);
      }
      return resolve({ id: doc.id, resource_version: doc.meta.versionId });
    });
  });
    // Return Id
  resolve({ id });
});

module.exports.update = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> update');
    let resource = req.body;

    let { base_version, id, } = args;
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.QUESTIONNAIRE_RESPONCE}_${base_version}`);


    collection.findOne({ id: id }, (err, data) => {
      if (err) {
        logger.error('Error with Patient.searchById: ', err);
        return reject(err);
      }

      let QuestionnaireResponse = getQuestionnaireResponse(base_version);
      let puestionnaireResponse = new QuestionnaireResponse(resource);

      if (data && data.meta) {
        let foundQuestionnaireResponse = new Patient(data);
        let meta = foundQuestionnaireResponse.meta;
        meta.versionId = `${parseInt(foundQuestionnaireResponse.meta.versionId) + 1}`;
        puestionnaireResponse.meta = meta;
      } else {
        let Meta = getMeta(base_version);
        puestionnaireResponse.meta = new Meta({
          versionId: '1',
          lastUpdated: moment.utc().format('YYYY-MM-DDTHH:mm:ssZ'),
        });
      }

      let cleaned = JSON.parse(JSON.stringify(puestionnaireResponse));
      let doc = Object.assign(cleaned);

      // Insert/update our patient record
      collection.findOneAndUpdate({ id: id }, { $set: doc }, { upsert: true }, (err2, res) => {
        if (err2) {
          logger.error('Error with Patient.update: ', err2);
          return reject(err2);
        }

        // save to history
        let history_collection = db.collection(`${COLLECTION.QUESTIONNAIRE_RESPONCE}_${base_version}_History`);

        let history_puestionnaireResponse = Object.assign(cleaned, { id: id });

        // Insert our patient record to history but don't assign _id
        return history_collection.insertOne(history_puestionnaireResponse, (err3) => {
          if (err3) {
            logger.error('Error with PatientHistory.create: ', err3);
            return reject(err3);
          }

          return resolve({
            id: id,
            created: res.lastErrorObject && !res.lastErrorObject.updatedExisting,
            resource_version: doc.meta.versionId,
          });
        });
      });
    });
  });

module.exports.remove = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> remove');

    let { id } = args;

    // TODO: delete record in database (soft/hard)

    // Return number of records deleted
    resolve({ deleted: 0 });
  });

module.exports.searchByVersionId = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> searchByVersionId');

    let { base_version, id, version_id } = args;

    let QuestionnaireResponse = getQuestionnaireResponse(base_version);

    // TODO: Build query from Parameters

    // TODO: Query database

    // Cast result to QuestionnaireResponse Class
    let questionnaireresponse_resource = new QuestionnaireResponse();

    // Return resource class
    resolve(questionnaireresponse_resource);
  });

module.exports.history = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> history');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let author = args['author'];
    let authored = args['authored'];
    let based_on = args['based-on'];
    let _context = args['_context'];
    let identifier = args['identifier'];
    let parent = args['parent'];
    let patient = args['patient'];
    let questionnaire = args['questionnaire'];
    let source = args['source'];
    let status = args['status'];
    let subject = args['subject'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let QuestionnaireResponse = getQuestionnaireResponse(base_version);

    // Cast all results to QuestionnaireResponse Class
    let questionnaireresponse_resource = new QuestionnaireResponse();

    // Return Array
    resolve([questionnaireresponse_resource]);
  });

module.exports.historyById = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('QuestionnaireResponse >>> historyById');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let author = args['author'];
    let authored = args['authored'];
    let based_on = args['based-on'];
    let _context = args['_context'];
    let identifier = args['identifier'];
    let parent = args['parent'];
    let patient = args['patient'];
    let questionnaire = args['questionnaire'];
    let source = args['source'];
    let status = args['status'];
    let subject = args['subject'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let QuestionnaireResponse = getQuestionnaireResponse(base_version);

    // Cast all results to QuestionnaireResponse Class
    let questionnaireresponse_resource = new QuestionnaireResponse();

    // Return Array
    resolve([questionnaireresponse_resource]);
  });
