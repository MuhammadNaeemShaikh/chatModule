/*eslint no-unused-vars: "warn"*/

const { VERSIONS } = require('@asymmetrik/node-fhir-server-core').constants;
const { resolveSchema } = require('@asymmetrik/node-fhir-server-core');
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const { ObjectID } = require('mongodb');
const { COLLECTION } = require('../../constants');

const logger = require('@asymmetrik/node-fhir-server-core').loggers.get();
const globals = require('../../globals');
const { getUuid } = require('../../utils/uid.util');

let getQuestionnaire = (base_version) => {
  return resolveSchema(base_version, 'Questionnaire');
};

let getMeta = (base_version) => {
  return resolveSchema(base_version, 'Meta');
};

module.exports.search = (args) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let code = args['code'];
    let date = args['date'];
    let description = args['description'];
    let effective = args['effective'];
    let identifier = args['identifier'];
    let jurisdiction = args['jurisdiction'];
    let name = args['name'];
    let publisher = args['publisher'];
    let status = args['status'];
    let title = args['title'];
    let url = args['url'];
    let version = args['version'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let Questionnaire = getQuestionnaire(base_version);

    // Cast all results to Questionnaire Class
    let questionnaire_resource = new Questionnaire();
    // TODO: Set data with constructor or setter methods
    questionnaire_resource.id = 'test id';

    // Return Array
    resolve([questionnaire_resource]);
  });

module.exports.searchById = (args) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> searchById');

    let { base_version, id } = args;

    let Questionnaire = getQuestionnaire(base_version);

    // TODO: Build query from Parameters

    // TODO: Query database

    // Cast result to Questionnaire Class
    let questionnaire_resource = new Questionnaire();
    // TODO: Set data with constructor or setter methods
    questionnaire_resource.id = 'test id';

    // Return resource class
    // resolve(questionnaire_resource);
    resolve();
  });

  module.exports.create = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> create');

    let { base_version } = args;
    // Make sure to use this ID when inserting this resource
    let id = new ObjectID().toString();

    let Questionnaire = getQuestionnaire(base_version);
    let Meta = getMeta(base_version);
    let resource = req.body;
    // TODO: determine if client/server sets ID

    // Cast resource to Questionnaire Class
    let questionnaire_resource = new Questionnaire(resource);
    questionnaire_resource.meta = new Meta();
    // TODO: set meta info

    // TODO: save record to database
      // Grab an instance of our DB and collection
      let db = globals.get(CLIENT_DB);
      let collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}`);
      // Create the document to be inserted into Mongo
      let doc = JSON.parse(JSON.stringify(questionnaire_resource.toJSON()));
      Object.assign(doc, { id: id });
      let history_doc = Object.assign({}, doc);
    Object.assign(doc, { id: id });

    // Insert our patient record
    collection.insertOne(doc, (err) => {
      if (err) {
        logger.error('Error with QUESTIONNAIRE.create: ', err);
        return reject(err);
      }

      // Save the resource to history
      let history_collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}_History`);

      // Insert our patient record to history but don't assign _id
      return history_collection.insertOne(history_doc, (err2) => {
        if (err2) {
          logger.error('Error with QUESTIONNAIREHistory.create: ', err2);
          return reject(err2);
        }
        return resolve({ id: doc.id, resource_version: doc.meta.versionId });
      });
    });
      // Return Id
    resolve({ id });
  });
module.exports.update = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> update');
    let { base_version, id } = args;
    let resource = req.body;
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}`);
    collection.findOne({ id: id.toString() }, (err, data) => {
      if (err) {
        logger.error('Error with Practitioner.searchById: ', err);
        return reject(err);
      }
      let Questionary = getQuestionnaire(base_version);
      let questionary = new Questionary(resource);

      if (data && data.meta) {
        let foundQuestionary = new (data);
        let meta = foundQuestionary.meta;
        meta.versionId = `${parseInt(foundQuestionary.meta.versionId) + 1}`;
        questionary.meta = meta;
      } else {
        let Meta = getMeta(base_version);
        questionary.meta = new Meta({
          versionId: '1',
          lastUpdated: moment.utc().format('YYYY-MM-DDTHH:mm:ssZ'),
        });
      }

      let cleaned = JSON.parse(JSON.stringify(questionary));
      let doc = Object.assign(cleaned);

      // Insert/update our patient record
      collection.findOneAndUpdate({ id: id }, { $set: doc }, { upsert: true }, (err2, res) => {
        if (err2) {
          logger.error('Error with Practitioner.update: ', err2);
          return reject(err2);
        }

        // save to history
        let history_collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}_History`);

        let history_questionary = Object.assign(cleaned, { id: id });

        // Insert our patient record to history but don't assign _id
        return history_collection.insertOne(history_questionary, (err3) => {
          if (err3) {
            logger.error('Error with questionaryHistory.create: ', err3);
            return reject(err3);
          }

          return resolve({
            id: id,
            created: res.lastErrorObject && !res.lastErrorObject.updatedExisting,
            resource_version: doc.meta.versionId,
          });
        });
      });
    });
  });

module.exports.remove = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> remove');

    let { base_version,id } = args;
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}`);
    // Delete our patient record
    collection.deleteOne({ id: id }, (err, _) => {
      if (err) {
        logger.error('Error with Patient.remove');
        return reject({
          // Must be 405 (Method Not Allowed) or 409 (Conflict)
          // 405 if you do not want to allow the delete
          // 409 if you can't delete because of referential
          // integrity or some other reason
          code: 409,
          message: err.message,
        });
      }

      // delete history as well.  You can chose to save history.  Up to you
      let history_collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}_History`);
      return history_collection.deleteMany({ id: id }, (err2) => {
        if (err2) {
          logger.error('Error with Patient.remove');
          return reject({
            // Must be 405 (Method Not Allowed) or 409 (Conflict)
            // 405 if you do not want to allow the delete
            // 409 if you can't delete because of referential
            // integrity or some other reason
            code: 409,
            message: err2.message,
          });
        }

        return resolve({ deleted: _.result && _.result.n });
      });
    });
  });

module.exports.searchByVersionId = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> searchByVersionId');

    let { base_version, id, version_id } = args;

    let Questionnaire = getQuestionnaire(base_version);

    // TODO: Build query from Parameters

    // TODO: Query database

    // Cast result to Questionnaire Class
    let questionnaire_resource = new Questionnaire();

    // Return resource class
    resolve(questionnaire_resource);
  });

module.exports.history = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> history');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let code = args['code'];
    let date = args['date'];
    let description = args['description'];
    let effective = args['effective'];
    let identifier = args['identifier'];
    let jurisdiction = args['jurisdiction'];
    let name = args['name'];
    let publisher = args['publisher'];
    let status = args['status'];
    let title = args['title'];
    let url = args['url'];
    let version = args['version'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let Questionnaire = getQuestionnaire(base_version);

    // Cast all results to Questionnaire Class
    let questionnaire_resource = new Questionnaire();

    // Return Array
    resolve([questionnaire_resource]);
  });

module.exports.historyById = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> historyById');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let code = args['code'];
    let date = args['date'];
    let description = args['description'];
    let effective = args['effective'];
    let identifier = args['identifier'];
    let jurisdiction = args['jurisdiction'];
    let name = args['name'];
    let publisher = args['publisher'];
    let status = args['status'];
    let title = args['title'];
    let url = args['url'];
    let version = args['version'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let Questionnaire = getQuestionnaire(base_version);

    // Cast all results to Questionnaire Class
    let questionnaire_resource = new Questionnaire();

    // Return Array
    resolve([questionnaire_resource]);
  });
/*eslint no-unused-vars: "warn"*/

// const { VERSIONS } = require('@asymmetrik/node-fhir-server-core').constants;
// const { resolveSchema } = require('@asymmetrik/node-fhir-server-core');
// const FHIRServer = require('@asymmetrik/node-fhir-server-core');
// const { ObjectID } = require('mongodb');
// // const logger = require('@asymmetrik/node-fhir-server-core').loggers.get();
// const { COLLECTION, CLIENT_DB } = require('../../constants');
// const globals = require('../../globals');
// let getQuestionnaire = (base_version) => {
//   return resolveSchema(base_version, 'Questionnaire');
// };

// let getMeta = (base_version) => {
//   return resolveSchema(base_version, 'Meta');
// };

module.exports.search = (args) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let code = args['code'];
    let date = args['date'];
    let description = args['description'];
    let effective = args['effective'];
    let identifier = args['identifier'];
    let jurisdiction = args['jurisdiction'];
    let name = args['name'];
    let publisher = args['publisher'];
    let status = args['status'];
    let title = args['title'];
    let url = args['url'];
    let version = args['version'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let Questionnaire = getQuestionnaire(base_version);

    // Cast all results to Questionnaire Class
    let questionnaire_resource = new Questionnaire();
    // TODO: Set data with constructor or setter methods
    questionnaire_resource.id = 'test id';

    // Return Array
    resolve([questionnaire_resource]);
  });

module.exports.searchById = (args) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> searchById');

    let { base_version, id } = args;

    let Questionnaire = getQuestionnaire(base_version);
       // Cast result to Questionnaire Class
       let questionnaire_resource = new Questionnaire();
      //  // TODO: Set data with constructor or setter methods
      //  questionnaire_resource.id = id;
         
// Grab an instance of our DB and collection
let db = globals.get(CLIENT_DB);
let collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}`);
    // TODO: Build query from Parameters

    // TODO: Query database
    collection.findOne({ id: id.toString() }, (err, questionnaire_resource) => {
      if (err) {
        logger.error('Error with Questionnaire.searchById: ', err);
        return reject(err);
      }
      if (questionnaire_resource) {
        resolve(new Questionnaire(questionnaire_resource));
      }
      resolve();
    });
 
    // Return resource class
    // resolve(questionnaire_resource);
    // resolve();
  });

module.exports.create = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> create');

    let { base_version } = args;
    // Make sure to use this ID when inserting this resource
    let id = new ObjectID().toString();

    let Questionnaire = getQuestionnaire(base_version);
    let Meta = getMeta(base_version);
    let resource = req.body;
    // TODO: determine if client/server sets ID

    // Cast resource to Questionnaire Class
    let questionnaire_resource = new Questionnaire(resource);
    questionnaire_resource.meta = new Meta();
    // TODO: set meta info

    // TODO: save record to database
      // Grab an instance of our DB and collection
      let db = globals.get(CLIENT_DB);
      let collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}`);
      // Create the document to be inserted into Mongo
      let doc = JSON.parse(JSON.stringify(questionnaire_resource.toJSON()));
      Object.assign(doc, { id: id });
      let history_doc = Object.assign({}, doc);
    Object.assign(doc, { id: id });

    // Insert our patient record
    collection.insertOne(doc, (err) => {
      if (err) {
        logger.error('Error with QUESTIONNAIRE.create: ', err);
        return reject(err);
      }

      // Save the resource to history
      let history_collection = db.collection(`${COLLECTION.QUESTIONNAIRE}_${base_version}_History`);

      // Insert our patient record to history but don't assign _id
      return history_collection.insertOne(history_doc, (err2) => {
        if (err2) {
          logger.error('Error with QUESTIONNAIREHistory.create: ', err2);
          return reject(err2);
        }
        return resolve({ id: doc.id, resource_version: doc.meta.versionId });
      });
    });
      // Return Id
    resolve({ id });
  });

module.exports.update = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> update');

    let { base_version, id, resource } = args;

    let Questionnaire = getQuestionnaire(base_version);
    let Meta = getMeta(base_version);

    // Cast resource to Questionnaire Class
    let questionnaire_resource = new Questionnaire(resource);
    questionnaire_resource.meta = new Meta();
    // TODO: set meta info, increment meta ID

    // TODO: save record to database

    // Return id, if recorded was created or updated, new meta version id
    resolve({
      id: questionnaire_resource.id,
      created: false,
      resource_version: questionnaire_resource.meta.versionId,
    });
  });

module.exports.remove = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> remove');

    let { id } = args;

    // TODO: delete record in database (soft/hard)

    // Return number of records deleted
    resolve({ deleted: 0 });
  });

module.exports.searchByVersionId = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> searchByVersionId');

    let { base_version, id, version_id } = args;

    let Questionnaire = getQuestionnaire(base_version);

    // TODO: Build query from Parameters

    // TODO: Query database

    // Cast result to Questionnaire Class
    let questionnaire_resource = new Questionnaire();

    // Return resource class
    resolve(questionnaire_resource);
  });

module.exports.history = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> history');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let code = args['code'];
    let date = args['date'];
    let description = args['description'];
    let effective = args['effective'];
    let identifier = args['identifier'];
    let jurisdiction = args['jurisdiction'];
    let name = args['name'];
    let publisher = args['publisher'];
    let status = args['status'];
    let title = args['title'];
    let url = args['url'];
    let version = args['version'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let Questionnaire = getQuestionnaire(base_version);

    // Cast all results to Questionnaire Class
    let questionnaire_resource = new Questionnaire();

    // Return Array
    resolve([questionnaire_resource]);
  });

module.exports.historyById = (args, context) =>
  new Promise((resolve, reject) => {
    logger.info('Questionnaire >>> historyById');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } =
      args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
      args;

    // Resource Specific params
    let code = args['code'];
    let date = args['date'];
    let description = args['description'];
    let effective = args['effective'];
    let identifier = args['identifier'];
    let jurisdiction = args['jurisdiction'];
    let name = args['name'];
    let publisher = args['publisher'];
    let status = args['status'];
    let title = args['title'];
    let url = args['url'];
    let version = args['version'];

    // TODO: Build query from Parameters

    // TODO: Query database

    let Questionnaire = getQuestionnaire(base_version);

    // Cast all results to Questionnaire Class
    let questionnaire_resource = new Questionnaire();

    // Return Array
    resolve([questionnaire_resource]);
  });
