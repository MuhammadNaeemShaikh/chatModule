/*eslint no-unused-vars: "warn"*/

const { VERSIONS } = require('@asymmetrik/node-fhir-server-core').constants;
const { resolveSchema } = require('@asymmetrik/node-fhir-server-core');
const { COLLECTION, CLIENT_DB } = require('../../constants');
const moment = require('moment-timezone');
const globals = require('../../globals');
const jsonpatch = require('fast-json-patch');
const { getUuid } = require('../../utils/uid.util');

const logger = require('@asymmetrik/node-fhir-server-core').loggers.get();


const {
  stringQueryBuilder,
  tokenQueryBuilder,
  referenceQueryBuilder,
  addressQueryBuilder,
  nameQueryBuilder,
  dateQueryBuilder,
} = require('../../utils/querybuilder.util');

let getPractitioner = (base_version) => {
  return resolveSchema(base_version, 'Practitioner');
};

let getMeta = (base_version) => {
  return resolveSchema(base_version, 'Meta');
};

/**
 *
 * @param {*} args
 * @param {*} context
 * @param {*} logger
//  */
let buildStu3SearchQuery = (args) => {
  // Common search params
  let { _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

  // Search Result params
  let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } =
    args;

  // Patient search params
  let active = args['active'];
  let address = args['address'];
  let address_city = args['address-city'];
  let address_country = args['address-country'];
  let address_postalcode = args['address-postalcode'];
  let address_state = args['address-state'];
  let address_use = args['address-use'];
  let birthdate = args['birthdate'];
  let death_date = args['death-date'];
  let deceased = args['deceased'];
  let email = args['email'];
  let family = args['family'];
  let gender = args['gender'];
  let general_practitioner = args['general-practitioner'];
  let given = args['given'];
  let identifier = args['identifier'];
  let language = args['language'];
  let link = args['link'];
  let name = args['name'];
  let organization = args['organization'];
  let phone = args['phone'];
  let phonetic = args['phonetic'];
  let telecom = args['telecom'];

  let query = {};
  let ors = [];

  if (address) {
    let orsAddresses = addressQueryBuilder(address);
    for (let orsAddress in orsAddresses) {
      ors.push(orsAddress);
    }
  }
  if (name) {
    let orsNames = nameQueryBuilder(name);
    for (let orsName in orsNames) {
      ors.push(orsName);
    }
  }
  console.log(ors);
  if (ors.length !== 0) {
    query.$and = ors;
  }

  if (_id) {
    query.id = _id;
  }

  if (active) {
    query.active = active === 'true';
  }

  if (address_city) {
    query['address.city'] = stringQueryBuilder(address_city);
  }

  if (address_country) {
    query['address.country'] = stringQueryBuilder(address_country);
  }

  if (address_postalcode) {
    query['address.postalCode'] = stringQueryBuilder(address_postalcode);
  }

  if (address_state) {
    query['address.state'] = stringQueryBuilder(address_state);
  }

  if (address_use) {
    query['address.use'] = address_use;
  }

  if (birthdate) {
    query.birthDate = dateQueryBuilder(birthdate, 'date', '');
  }

  if (death_date) {
    query.deceasedDateTime = dateQueryBuilder(death_date, 'dateTime', '');
  }

  if (deceased) {
    query.deceasedBoolean = deceased === 'true';
  }

  // Forces system = 'email'
  if (email) {
    let queryBuilder = tokenQueryBuilder(email, 'value', 'telecom', 'email');
    for (let i in queryBuilder) {
      query[i] = queryBuilder[i];
    }
  }

  if (family) {
    query['name.family'] = stringQueryBuilder(family);
  }

  if (gender) {
    query.gender = gender;
  }

  if (given) {
    query['name.given'] = stringQueryBuilder(given);
  }

  if (identifier) {
    let queryBuilder = tokenQueryBuilder(identifier, 'value', 'identifier', '');
    for (let i in queryBuilder) {
      query[i] = queryBuilder[i];
    }
  }

  if (language) {
    let queryBuilder = tokenQueryBuilder(language, 'code', 'communication.language.coding', '');
    for (let i in queryBuilder) {
      query[i] = queryBuilder[i];
    }
  }

  if (organization) {
    let queryBuilder = referenceQueryBuilder(organization, 'managingOrganization.reference');
    for (let i in queryBuilder) {
      query[i] = queryBuilder[i];
    }
  }

  // Forces system = 'phone'
  if (phone) {
    let queryBuilder = tokenQueryBuilder(phone, 'value', 'telecom', 'phone');
    for (let i in queryBuilder) {
      query[i] = queryBuilder[i];
    }
  }

  // TODO:  mongo doesn't natively support fuzzy but there are ways to do it
  // or use Elastic?
  //
  // if (phonetic) {
  //
  // }

  if (telecom) {
    let queryBuilder = tokenQueryBuilder(telecom, 'value', 'telecom', '');
    for (let i in queryBuilder) {
      query[i] = queryBuilder[i];
    }
  }

  return query;
};

module.exports.search = async (args, context) => {
  let { base_version } = args;
  let BundleEntry = resolveSchema(args.base_version, 'bundleentry');
  let Bundle = resolveSchema(args.base_version, 'bundle');
  // let Patient = resolveSchema(args.base_version, 'patient');
  let Practitioner = getPractitioner(base_version);
    // Grab an instance of our DB and collection
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}`);
  // You will need to build your query based on the sanitized args
  let query = buildStu3SearchQuery(args);
  let results = await collection.find(query).toArray();
  let practitioners = results.map((result) => new Practitioner(result));
  let entries = practitioners.map((practitioner) => new BundleEntry({ resource: practitioner }));
  return new Bundle({ entry: entries });
};


module.exports.searchById = (args) =>
  new Promise((resolve, reject) => {
    logger.info('Practitioner >>> searchById');

    let { base_version, id } = args;
    let Practitioner = getPractitioner(base_version);

    // Grab an instance of our DB and collection
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}`);
    // Query our collection for this observation
    collection.findOne({ id: id.toString() }, (err, practitioner) => {
      if (err) {
        logger.error('Error with Practitioner.searchById: ', err);
        return reject(err);
      }
      if (practitioner) {
        resolve(new Practitioner(practitioner));
      }
      resolve();
    });
  });

module.exports.create = ( args, {req, res} ) =>
  new Promise((resolve, reject) => {
    logger.info('Practitioner >>> create');

    let resource = req.body;
    // let userId  = req.body.id;

    let { base_version } = args;

    // Grab an instance of our DB and collection (by version)
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}`);

    // Get current record
    let Practitioner = getPractitioner(base_version);
    let practitioner = new Practitioner(resource);

    // If no resource ID was provided, generate one.
    let id = getUuid(practitioner);

    // Create the resource's metadata
    let Meta = getMeta(base_version);
    practitioner.meta = new Meta({
      versionId: '1',
      lastUpdated: moment.utc().format('YYYY-MM-DDTHH:mm:ssZ'),
    });

    // Create the document to be inserted into Mongo
    let doc = JSON.parse(JSON.stringify(practitioner.toJSON()));
    Object.assign(doc, { id: id});

    // Create a clone of the object without the _id parameter before assigning a value to
    // the _id parameter in the original document
    let history_doc = Object.assign({}, doc);
    Object.assign(doc, { id: id});

    // Insert our patient record
    collection.insertOne(doc, (err) => {
      if (err) {
        logger.error('Error with Practitioner.create: ', err);
        return reject(err);
      }
      
      // Save the resource to history
            let history_collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}_History`);

      // Insert our patient record to history but don't assign _id
      return history_collection.insertOne(history_doc, (err2) => {
        if (err2) {
          logger.error('Error with PractitionerHistory.create: ', err2);
          return reject(err2);
        }

        // const router = express.Router();   
         
        return resolve({ id: doc.id, resource_version: doc.meta.versionId });
      });
    });
  });

  //======================================================
  module.exports.update = (args, { req }) =>
  new Promise((resolve, reject) => {
    logger.info('Practitioner >>> update');

    let resource = req.body;

    let { base_version, id } = args;

    // Grab an instance of our DB and collection
    let db = globals.get(CLIENT_DB);
    let collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}`);

    // Get current record
    // Query our collection for this observation
    collection.findOne({ id: id.toString() }, (err, data) => {
      if (err) {
        logger.error('Error with Practitioner.searchById: ', err);
        return reject(err);
      }

      let Practitioner = getPractitioner(base_version);
      let practitioner = new Practitioner(resource);

      if (data && data.meta) {
        let foundPractitioner = new Practitioner(data);
        let meta = foundPractitioner.meta;
        meta.versionId = `${parseInt(foundPractitioner.meta.versionId) + 1}`;
        practitioner.meta = meta;
      } else {
        let Meta = getMeta(base_version);
        practitioner.meta = new Meta({
          versionId: '1',
          lastUpdated: moment.utc().format('YYYY-MM-DDTHH:mm:ssZ'),
        });
      }

      let cleaned = JSON.parse(JSON.stringify(practitioner));
      let doc = Object.assign(cleaned);

      // Insert/update our patient record
      collection.findOneAndUpdate({ id: id }, { $set: doc }, { upsert: true }, (err2, res) => {
        if (err2) {
          logger.error('Error with Practitioner.update: ', err2);
          return reject(err2);
        }

        // save to history
        let history_collection = db.collection(`${COLLECTION.PRACTITIONER}_${base_version}_History`);

        let history_practitioner = Object.assign(cleaned, { id: id });

        // Insert our patient record to history but don't assign _id
        return history_collection.insertOne(history_practitioner, (err3) => {
          if (err3) {
            logger.error('Error with PractitionerHistory.create: ', err3);
            return reject(err3);
          }

          return resolve({
            id: id,
            created: res.lastErrorObject && !res.lastErrorObject.updatedExisting,
            resource_version: doc.meta.versionId,
          });
        });
      });
    });
  });