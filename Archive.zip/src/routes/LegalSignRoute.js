const express = require('express');
const LegalSignClt = require("../controller/LegalSignClt");
const { protect } = require('../middleware/authChatMiddleware');
// const requireAuth= require('../middleware/requireAuth')

const router = express.Router();

router.route('/').post(protect, LegalSignClt.createLegalSign);
router.route('/').get(protect, LegalSignClt.getLegalSign);
// router.route('/:chatId').get(protect, allMessages);

module.exports = router;