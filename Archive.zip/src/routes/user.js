const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/user');
const {protect} = require('../middleware/authChatMiddleware')
   const crypto = require('crypto');
// controller functions
const { loginUser, signupUser, verifyEmail, forgotPassword, verifyOtp } = require('../controller/user');


const router = express.Router()



router.get('/check',(req,res)=>{
   res.send("Hellow world")
})

// login route
// signup route
router.post('/signup', signupUser);
router.post('/login', loginUser);

router.put('/update-fhirid/:id', async(req, res) => {

   const id = req.params.id;
   let otpCode = Math.floor((Math.random()*10000) + 1);

   try {
const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
     let result;
      async function generateRandomString(length) {
         result = '';
         let charactersLength = characters.length;
         for (let i = 0; i < length; i++) {
           result += characters.charAt(crypto.randomBytes(1)[0] % charactersLength);
         }
      }
    console.log(generateRandomString(4));
    const string = await User.findOne({ clinitionCode: result });
    if (string) {
      result = await generateRandomString(4);
    }
       const user = await User.findByIdAndUpdate(id, {
           fhirid: req.body.fhirid,
           clinitionCode: result,
           name: req.body.name,
           profilePic: req.body.pic,
       },{
         new: true
       });
      //  await user.save();
       res.json(user);

      } catch (error) {
         res.status(500).json({error: error.message });
      }
});

router.get('/userinfo',protect, async (req,res) =>{ 
try {
   const id = req.user._id
   const user = await User.findById(id);
   // res.json({user})
   const type = user.type;
   const email = user.email;
    const fhirid = user.fhirid;
    const name = user.name;
    const profilePic = user.profilePic; 
   res.json({email, type, id, fhirid, name, profilePic})
} catch (error) {
   res.status(500).json({error : error.message});
}
});

//Get All Users
router.get('/users', function(req, res) {
   User.find({}, function(err, users) {
 
     res.status(200).json({users});  
   }).select("-password");
 });

router.put('/changepassword', protect, async(req,res)=>{
   const id = req.user._id;
   const {oldpassword, newpassword} = req.body;
   try {
   const user = await User.findById(id);
   const salt = await bcrypt.genSalt(10)
   const newPassword = await bcrypt.hash(newpassword, salt);
   const match = await bcrypt.compare(oldpassword, user.password);
   if (!match) {
      res.json({msg: 'Password did not matched'});
   }
   else {
      const user = await User.findByIdAndUpdate(id, {
           password: newPassword
       },{
         new: true
       });
       await user.save();
       res.json({msg: 'Password updated successfully'});
   }
}
catch (error) {
   res.status(500).json({error: error.message});
}
});



// api for get cliniton fhir id in 
router.get('/getfhirid', async (req,res) =>{
   try {
      const user = await User.findOne({clinitionCode:req.body.clinitionCode});
      const type = user.type;
      const email = user.email;
      const fhirid = user.fhirid;
     res.json({fhirid,email,type})
   } catch (error) {
      res.status(500).json({error: error.message});
   }

}
)
// const getFhirId = 
router.post('/sendemail', verifyEmail);
router.post('/verifyotp', verifyOtp);
router.post('/forgotpassword', forgotPassword);
module.exports = router
// router.post("/login", userController.loginUser );