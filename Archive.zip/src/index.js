const cors = require("cors")
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
require('dotenv').config();
require('@asymmetrik/node-fhir-server-core').loggers.get();
const asyncHandler = require('./lib/async-handler');
const mongoClient = require('./lib/mongo');
const globals = require('./globals');
const express = require('express');
const app = express();

// eslint-disable-next-line new-cap
var http = require('http').Server(app);
const userRoutes = require('./routes/user');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const env = require('var');
const chatRoutes = require("./routes/chatRoutes");
const messageRoutes = require("./routes/messageRoutes");
const callRoutes = require("./routes/call_route");
const legalSignRoute = require("./routes/LegalSignRoute");

//Socket Logic
const socket = require('socket.io')
// const chatRoomRouter = require("./routes/chatRoom");

// const app1 = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const { fhirServerConfig, mongoConfig } = require('./config');

const { CLIENT, CLIENT_DB } = require('./constants');

let main = async function () {
  // Connect to mongo and pass any options here
  let [mongoErr, client] = await asyncHandler(
    mongoClient(mongoConfig.connection)
  );

  if (mongoErr) {
    console.error(mongoErr.message);
    console.error(mongoConfig.connection);
    process.exit(1);
  }

  // Save the client in another module so I can use it in my services
  globals.set(CLIENT, client);
  globals.set(CLIENT_DB, client.db(mongoConfig.db_name));
  mongoose.connect('mongodb+srv://JamesDoe:jamesDoe123@cluster0.7vmtnoj.mongodb.net/?retryWrites=true&w=majority')
    .then(() => {
      console.log('Connected to DB');
    })
    .catch(() => {
      console.log('Connection Failed');
    });

app.use(cors());
app.options('*', cors());
app.use('/api/user', userRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/message', messageRoutes);
app.use("/api/call", callRoutes);
app.use("/api/legalSign", legalSignRoute);

 
  const io = await require('socket.io')(http, {
    cors: {
      origin:"*",
    },
  });
  global.onlineUsers = new Map();
  io.on("connection", (socket) => {
    console.log("Connected to socket.io");
         global.chatSocket = socket;
    socket.on("setup", (userId) => {

      console.log("User is connected",userId);

      socket.join(userId);
      socket.emit("connected");
    });

  socket.on('testing', (data) => {
    console.log(data);
  });
    socket.on('join chat', (room) => {
      socket.join(room);
      console.log("User Joined Room: " + room);
    });

    socket.on("leave chat", (room) => {
      socket.leave(room);
      console.log("User Joined Room: " + room);
    });
    socket.on("typing", (room) => socket.in(room).emit("typing"));
    socket.on("stop typing", (room) => socket.in(room).emit("stop typing"));

    socket.on("new message", (data) => {
      console.log(data);
      const senderId = data.chat._id;
      console.log('room id', senderId);
      chats = data.chat;

      io.in(data.chat._id).emit("message-recieved", data);
    });

    socket.on("call", (data) => {
      console.log("Socket Call data is here", data);
      const callId = data.callId;
      console.log("Call ID", callId);
      io.to(callId).emit("call-recieved", data);
      // socket.emit("call-recieved", data);
    });
    socket.off("setup", () => {
      console.log("USER DISCONNECTED");
      socket.leave(userId);
    });
  });
  //io.on('connection', WebSockets.connection)
  // Start our FHIR server
  //port forwarded on 3000
  let server = FHIRServer.initialize(fhirServerConfig, app)
  // .configurePassport()
  // app.use(cors())
  server.listen(fhirServerConfig.server.port);
  http.listen(5000, () => {
    console.log('Server listening on 5000');
  });
};

main();