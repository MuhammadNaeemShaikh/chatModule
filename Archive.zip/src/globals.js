/**
 * @name exports
 * @summary Simple map to store globals in
 */
module.exports = new Map();
