const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')
const validator = require('validator')

const Schema = mongoose.Schema

const LegalSignSchema = new Schema({
  name: {
    type: String,
    unique: true
  },
  physician: {
    type: String,
  },
   neuroCare: {
    type: String,
  },
  address:{
    type: String,
    default: ""
  },
  email: {
    type: String,
    default: ""
  },
  sign: {
    type: String,
    default: ""
  },
  // clinitionCode
  date: {
    type: Date,
    default: Date.now
  }
})

module.exports = mongoose.model('LegalSignData', LegalSignSchema)